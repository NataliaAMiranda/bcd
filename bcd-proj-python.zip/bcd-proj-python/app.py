from flask import Flask, render_template, session, redirect, url_for, flash
from flask_bootstrap import Bootstrap
from flask_nav import Nav
from flask_nav.elements import Navbar, View, Subgroup, Link
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from sqlalchemy.testing import db
from werkzeug.security import generate_password_hash, check_password_hash
from wtforms import StringField, SubmitField
from wtforms import PasswordField
from wtforms.validators import DataRequired

SECRET_KEY = 'aula de BCD - string aleatoria'
app = Flask(__name__)
app.secret_key = SECRET_KEY

bootstrap = Bootstrap(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///BancoQ.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

nav = Nav()
nav.init_app(app)  # menu no topo da página


@nav.navigation()
def menunav():
    menu = Navbar('Gerador de Questões')
    menu.items = [View('Home', 'hello_world'), View('Login', 'autenticar'), View('Inserir', 'inserir')]
    menu.items.append(Subgroup('Listar', View('Disciplina', 'disciplinas')))
    menu.items.append(Link('Ajuda', 'https://google.com'))

    return menu


class Usuario(db.Model):
    idUsuario = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(40))
    password = db.Column(db.String(130))

    def set_password(self, password):
        self.password = generate_password_hash('password')

    def check_password(self, password):
        return check_password_hash(self.password, password)


class LoginForm(FlaskForm):
    username = StringField('Nome Usuário', validators=[DataRequired()])
    password = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Entrar')


class Disciplinas(db.Model):
    __tablename__ = "Disciplina"
    idDisciplina = db.Column(db.Integer, primary_key=True)
    nomeD = db.Column(db.String(100), unique=True)
    Usuario_idUsuario = db.Column(db.Integer, db.ForeignKey("Usuario.idUsuario"))

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.nomeD = kwargs.pop('nomeD')
        self.idUsuario = kwargs.pop('idUsuario')


class CadastroDisciplinas(FlaskForm):
    nome = StringField('Disciplina', validators=[DataRequired("")])
    submit = SubmitField('Inserir')


class Categoria(db.Model):
    __tablename__ = "Categoria"
    idCategoria = db.Column(db.Integer, primary_key=True)
    nomeC = db.Column(db.String(100), unique=True)
    Disciplina_idDisciplina = db.Column(db.Integer, db.ForeignKey("Disciplinas.idDisciplina"))

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.idCategoria = kwargs.pop('idCategoria')
        self.nomeC = kwargs.pop('nomeC')
        self.idDisciplina = kwargs.pop('Disciplina_idDisciplina')


class Questoes(db.Model):
    __tablename__ = "Questoe"
    idQuestao = db.Column(db.Integer, primary_key=True)
    questao = db.Column(db.String(8000), unique=True)
    resposta = db.Column(db.String(8000), unique=True)
    data_Questao = db.Column(db.Date)
    tipo = db.Column(db.String(100), unique=True)
    Categoria_idCategoria = db.Column(db.Integer, db.ForeignKey("Categoria.idCategoria"))

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.idQuestao = kwargs.pop('idQuestao')
        self.questao = kwargs.pop('questao')
        self.resposta = kwargs.pop('resposta')
        self.data_Questao = kwargs.pop('data_Questao')
        self.tipo = kwargs.pop('tipo')
        self.Categoria_idCategoria = kwargs.pop('Categoria_idCategoria')


class Provas(db.Model):
    __tablename__ = "Prova"
    idProva = db.Column(db.Integer, primary_key=True)
    Disciplina_idDisciplina = db.Column(db.Integer, db.ForeignKey("Disciplina.idDisciplina"))
    semestre = db.Column(db.String(100), unique=True)
    data_prova = db.Column(db.Date)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.idProva = kwargs.pop('idProva')
        self.Disciplina_idDisciplina = kwargs.pop('Disciplina_idDisciplina')
        self.semestre = kwargs.pop('semestre')
        self.data_prova = kwargs.pop('data_prova')


@app.route('/login', methods=['GET', 'POST'])
def autenticar():
    form = LoginForm()
    if form.validate_on_submit():
        usuario = Usuario.query.filter_by(username=form.username.data).first_or_404()
        if usuario.check_password(form.password.data):
            session['logged_in'] = True
            session['username'] = usuario.username
            session['idUsuario'] = usuario.idUsuario
            return render_template('autenticado.html', title="Usuário autenticado", user=session.get('usuario'))
        else:
            flash('Usuário ou senha inválidos')
            return redirect(url_for('hello_world'))
    return render_template('login.html', title='Autenticação', form=form)


@app.route('/painel')
def painel():
    if session.get('logged_in') is True:
        # Veja mais em: //flask-sqlalchemy.pocoo.org/2.3/queries/#querying-records
        usuario = Usuario.query.filter_by(username=session.get('usuario')).first_or_404()
        return render_template('dados.html', title="Usuário autenticado", user=usuario)
    return redirect(url_for('autenticar'))


@app.route('/logout')
def sair():
    session['logged_in'] = False
    return redirect(url_for('autenticar'))


@app.route('/disciplina', methods=['GET', 'POST'])
def disciplinas():
    select_disciplinas = Disciplinas.query.all()

    return render_template('disciplina.html', title='Listar Disciplinas', disciplinas=select_disciplinas)


@app.route('/inserir')
def inserir():
    form = CadastroDisciplinas()
    if form.validate_on_submit():
        novaDisciplina = Disciplinas(nomeD=form.nomeD.data, idUsuario=session['idUsuario'])
        db.session.add(novaDisciplina)
        db.session.commit()
        return redirect(url_for('disciplina'))
    return render_template('inserir.html', title='Inserir', form=form)


@app.route('/')
def hello_world():
    if session.get('logged_in') is True:
        return redirect(url_for('autenticar'))
    else:
        return render_template('autenticado.html', title='Usuário autenticado', user=session.get('usuario'))


if __name__ == '__main__':
    app.run()
